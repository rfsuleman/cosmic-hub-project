package com.suleman.purestatus

import android.content.ContentValues
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var compressButton: Button
    private lateinit var splitButton: Button
    private var selectedVideo: Uri? = null
    private var busy = false

    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideo = uri
        if (uri != null) {
            status.text = "Video selected. Choose an action below."
            compressButton.isEnabled = true
            splitButton.isEnabled = true
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) savePhotoCopy(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
    }

    private fun buildInterface() {
        val background = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(0xFF10111B.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val brand = TextView(this).apply {
            text = "PURE STATUS"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            letterSpacing = .12f
            gravity = Gravity.CENTER
        }
        val byline = TextView(this).apply {
            text = "by SULEMAN"
            textSize = 14f
            setTextColor(0xFFB8B5FF.toInt())
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "Make every status look its best."
            textSize = 15f
            setTextColor(0xFFB8BBCB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(26))
        }
        val choose = button("Choose a video")
        choose.setOnClickListener { videoPicker.launch("video/*") }
        compressButton = button("Compress for WhatsApp")
        compressButton.isEnabled = false
        compressButton.setOnClickListener { compressSelectedVideo() }
        splitButton = button("Split into 30-second parts")
        splitButton.isEnabled = false
        splitButton.setOnClickListener { splitSelectedVideo() }
        val photo = button("Prepare a photo status")
        photo.setOnClickListener { photoPicker.launch("image/*") }

        status = TextView(this).apply {
            text = "Choose a video or photo to begin."
            textSize = 14f
            setTextColor(0xFFE3E4EF.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(24), dp(8), dp(12))
        }
        progress = ProgressBar(this).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        val note = TextView(this).apply {
            text = "Processing happens on your phone. Original files stay untouched. Videos are saved in this app’s Movies/PureStatus folder."
            textSize = 12f
            setTextColor(0xFF9296AA.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(22), dp(8), 0)
        }
        content.addView(brand)
        content.addView(byline)
        content.addView(intro)
        content.addView(choose, match())
        content.addView(compressButton, match())
        content.addView(splitButton, match())
        content.addView(photo, match())
        content.addView(progress)
        content.addView(status)
        content.addView(note)
        scroll.addView(content)
        background.addView(scroll)
        setContentView(background)
    }

    private fun button(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(0xFFFFFFFF.toInt())
        backgroundTintList = ContextCompat.getColorStateList(this@MainActivity, android.R.color.holo_purple)
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun match() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(10) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun setBusy(value: Boolean, message: String) {
        runOnUiThread {
            busy = value
            progress.visibility = if (value) View.VISIBLE else View.GONE
            compressButton.isEnabled = !value && selectedVideo != null
            splitButton.isEnabled = !value && selectedVideo != null
            status.text = message
        }
    }

    private fun outputFile(prefix: String, extension: String = "mp4"): File {
        val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "PureStatus")
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(dir, "${prefix}_$stamp.$extension")
    }

    private fun compressSelectedVideo() {
        val uri = selectedVideo ?: return
        if (busy) return
        setBusy(true, "Compressing video… keep the app open.")
        val out = outputFile("PureStatus_HD")
        try {
            val transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        setBusy(false, "Done! Saved: ${out.name}\nUse Share to post it to WhatsApp.")
                        Toast.makeText(this@MainActivity, "Video ready", Toast.LENGTH_LONG).show()
                    }
                    override fun onError(
                        composition: androidx.media3.transformer.Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        out.delete()
                        setBusy(false, "Could not compress this video: ${exportException.message}")
                    }
                }).build()
            transformer.start(EditedMediaItem.Builder(MediaItem.fromUri(uri)).build(), out.absolutePath)
        } catch (e: Exception) {
            out.delete()
            setBusy(false, "Compression failed: ${e.message}")
        }
    }

    private fun splitSelectedVideo() {
        val uri = selectedVideo ?: return
        if (busy) return
        setBusy(true, "Splitting video into 30-second parts…")
        worker.execute {
            try {
                val extractor = MediaExtractor()
                extractor.setDataSource(this, uri, null)
                val tracks = (0 until extractor.trackCount).map { extractor.getTrackFormat(it) }
                val durationUs = tracks.mapNotNull {
                    if (it.containsKey(MediaFormat.KEY_DURATION)) it.getLong(MediaFormat.KEY_DURATION) else null
                }.maxOrNull() ?: throw IllegalStateException("Video duration unavailable")
                val outputs = mutableListOf<File>()
                var startUs = 0L
                var part = 1
                while (startUs < durationUs) {
                    val endUs = minOf(startUs + 30_000_000L, durationUs)
                    val out = outputFile("PureStatus_Part$part")
                    muxRange(uri, out, startUs, endUs)
                    outputs.add(out)
                    startUs = endUs
                    part++
                }
                runOnUiThread {
                    setBusy(false, "Done! ${outputs.size} part(s) saved:\n" +
                        outputs.joinToString("\n") { it.name })
                }
                extractor.release()
            } catch (e: Exception) {
                setBusy(false, "Split failed: ${e.message}")
            }
        }
    }

    private fun muxRange(uri: Uri, output: File, startUs: Long, endUs: Long) {
        val extractor = MediaExtractor()
        extractor.setDataSource(this, uri, null)
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val trackMap = HashMap<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                trackMap[i] = muxer.addTrack(format)
            }
        }
        if (trackMap.isEmpty()) throw IllegalStateException("No audio/video tracks found")
        muxer.start()
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buffer = java.nio.ByteBuffer.allocate(4 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        while (true) {
            val track = extractor.sampleTrackIndex
            if (track < 0) break
            val time = extractor.sampleTime
            if (time >= endUs) break
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            info.set(0, size, maxOf(0L, time - startUs), extractor.sampleFlags)
            trackMap[track]?.let { muxer.writeSampleData(it, buffer, info) }
            if (!extractor.advance()) break
        }
        muxer.stop()
        muxer.release()
        extractor.release()
    }

    private fun savePhotoCopy(uri: Uri) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PureStatus_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, contentResolver.getType(uri) ?: "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PureStatus")
            }
            val dest = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create output file")
            contentResolver.openInputStream(uri).use { input ->
                contentResolver.openOutputStream(dest).use { output ->
                    if (input == null || output == null) throw IllegalStateException("Could not open image")
                    input.copyTo(output)
                }
            }
            status.text = "Photo copied to Pictures/PureStatus. Original quality preserved."
        } catch (e: Exception) {
            status.text = "Could not prepare photo: ${e.message}"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}

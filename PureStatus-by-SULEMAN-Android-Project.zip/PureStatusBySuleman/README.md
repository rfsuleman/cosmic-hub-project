# Pure Status by SULEMAN

An original Android app inspired by the general idea of preparing clear WhatsApp status media. It does not include copied PureStatus source code, branding, assets, or proprietary implementation.

## Current features
- Native Android photo/video picker (no broad storage permission).
- Video re-encoding to H.264/AAC using AndroidX Media3 Transformer.
- 30-second MP4 splitting using MediaExtractor + MediaMuxer (stream-copy; segment boundaries align to available sync samples).
- Photo copy to `Pictures/PureStatus`.
- Videos are written to the app-specific external Movies/PureStatus folder; photos are copied to the public Pictures/PureStatus folder.

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Install Android SDK 35 and JDK 17 when prompted.
4. Wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build from GitHub Actions
Push this folder to a GitHub repository. The workflow at `.github/workflows/android.yml` builds a debug APK and publishes it as an artifact.

## Important notes
- Compression re-encodes video; it can reduce file size, but cannot restore detail already lost in the source.
- The current compressor uses the platform's default Media3 export settings. A future settings screen can expose target resolution/bitrate.
- Split output may start at the nearest preceding keyframe; some parts can be a little longer/shorter than exactly 30 seconds. This avoids unnecessary re-encoding.
- Test on real devices with different codecs, HDR videos, and long recordings before publishing.
- This source project has not been compiled or device-tested in this environment.
